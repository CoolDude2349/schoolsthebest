Hi. Does not use files anymore. Just click the link and have fun!
Also, you can view it offline. Singleplication may not work tho 

So this is mainly recommended for offline viewing.

The local storage is a backup in case service workers don't work. But you have to go to the website online first. There is a trick to do that in case it's getting blocked. Even if you only got to see a glimpse of the website content, it should work offline. If iframes to specfic websites are not blocked, then you can also use that to directly access the website offline. (After viewing it online first with an iframe)

Also: Local storage may not last long so you will have to go to the website online again to cache again. (This is only if service workers don't work.)
